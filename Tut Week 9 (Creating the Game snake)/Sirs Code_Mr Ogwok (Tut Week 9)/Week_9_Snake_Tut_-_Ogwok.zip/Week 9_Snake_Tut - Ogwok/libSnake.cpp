#include "libSnake.h"

#include <sstream>
#include <cstdlib>

namespace SnakeSpace{

int convStrToInt(string strNum){
    int intNum = 0;
    stringstream ss {strNum};
    ss >> intNum;
    if(ss.fail()){
        cerr << "Failed to convert to Integer" << endl;
        exit(ERR_CONVERT);
    }
    return intNum;
}

int genRandomNum(int intLower, int intUpper){
    int intRange = intUpper - intLower + 1;
    return rand() % intRange + intLower;
}

//void placeFeature(TwoDArray arrGame, int intRows, int intCols, int intFeature){
void placeFeature(GameWorld& myGameWorld, int intFeature){
    int intRow = genRandomNum(0, myGameWorld.intRows - 1);
    int intCol = genRandomNum(0, myGameWorld.intCols - 1);
    while(myGameWorld.arrGame[intRow][intCol] != GRASS){
        intRow = genRandomNum(0, myGameWorld.intRows - 1);
        intCol = genRandomNum(0, myGameWorld.intCols - 1);
    }
    //Grass
    myGameWorld.arrGame[intRow][intCol] = intFeature;
}

void placeSnake(GameWorld& myGameWorld){
    //Place Head
    int intRow = genRandomNum(0, myGameWorld.intRows - 1);  //Between Minus 2 & 1 to avoid edge, since tail attached too
    int intCol = genRandomNum(1, myGameWorld.intCols - 2);  //Between Minus 2 & 1 to avoid edge, since tail attached too
    //Store Head Position
    Coordinate snakeHead;
    snakeHead.intRow = intRow;
    snakeHead.intCol = intCol;
    myGameWorld.snakeHead = snakeHead;
    myGameWorld.arrGame[intRow][intCol] = SNAKE_HEAD;
    //Place Tail
    //intRow = intRow - 1; //Keep on same Row
    intCol = intCol - 1;
    //Store Tail Position
    myGameWorld.snakeTail = {intRow, intCol};
    myGameWorld.arrGame[intRow][intCol] = SNAKE_TAIL;
}

GameWorld createGame(int intRows, int intCols){
    GameWorld myGameWorld;
    myGameWorld.intRows = intRows;
    myGameWorld.intCols = intCols;
    //Allocate Memory
    myGameWorld.arrGame = new OneDArray[intRows];
    for(int r = 0; r < intRows; r++){
        myGameWorld.arrGame[r] = new int[intCols];
        for(int c = 0; c < intCols; c++){
            //Initialize to Grass
            myGameWorld.arrGame[r][c] = GRASS;
        }
    }
    myGameWorld.fruitsCollected = 0;
    myGameWorld.ateSelf = false;
    //Place Features (Snake and Fruit)
    //placeSnake(arrGame, intRows, intCols);
    placeSnake(myGameWorld);
    placeFeature(myGameWorld, FRUIT);
    return myGameWorld;
}

void printGame(const GameWorld& myGameWorld){
    for(int r = 0; r < myGameWorld.intRows; r++){
        for(int c = 0; c < myGameWorld.intCols; c++){
            cout << (char) FEATURE_CHARS[myGameWorld.arrGame[r][c]] << " ";
        }
        cout << endl;
    }

    cout << endl;
    //Menu
    cout << "Press to move W) UP , S) DOWN , A) LEFT , D) RIGHT , Q) QUIT" << endl;

}

void destroyGame(GameWorld& myGameWorld){
    for(int r = 0; r < myGameWorld.intRows; r++){
        delete [] myGameWorld.arrGame[r];
    }
    delete [] myGameWorld.arrGame;
    myGameWorld.arrGame = nullptr;
}

void pauseGame(){
    cin.ignore(1000, '\n');
    cout << "Press Enter to Continue" << endl;
    cin.get();
}

//void findFeature(TwoDArray arrGame, int intRows, int intCols, int &intRow, int &intCol, int intFeature){
//    for(int r = 0; r < intRows; r++){
//        for(int c = 0; c < intCols; c++){
//            if(arrGame[r][c] == intFeature){
//                intRow = r;
//                intCol = c;
//                return;
//            }
//        }
//    }
//}

bool isValid(int intRows, int intCols, int intDR, int intDC){
    return (intDR >= 0 && intDR < intRows && intDC >= 0 && intDC < intCols);
}

void moveSnakeBody(GameWorld &myGameWorld, Coordinate prevHead){
    //Move Snake Body
    vector<Coordinate> tempBody;
    //First segment of body replaces head
    myGameWorld.arrGame[prevHead.intRow][prevHead.intCol] = SNAKE_BODY;
    Coordinate recCordinates;
    recCordinates.intRow = prevHead.intRow;
    recCordinates.intCol = prevHead.intCol;
    tempBody.push_back(recCordinates);
    for(int i = 0; i < myGameWorld.snakeBody.size() - 1; i++){
        //arrGame[snakeBody[i].intRow][snakeBody[i].intCol]
        recCordinates.intRow = myGameWorld.snakeBody[i].intRow;
        recCordinates.intCol = myGameWorld.snakeBody[i].intCol;
        tempBody.push_back(recCordinates);
    }

    //The last value in the vector will store tail
    int intRow = myGameWorld.snakeBody[myGameWorld.snakeBody.size() - 1].intRow;
    int intCol = myGameWorld.snakeBody[myGameWorld.snakeBody.size() - 1].intCol;
    //tempBody.push_back(recCordinates);
    myGameWorld.snakeTail = {intRow, intCol};
    myGameWorld.arrGame[intRow][intCol] = SNAKE_TAIL;
    //change game body
    myGameWorld.snakeBody = tempBody;
}

void moveSnake(GameWorld& myGameWorld, char chInput){
//    int intSR = -1;
//    int intSC = -1;

    //findFeature, snake head -> I know the value
    //findFeature(arrGame, intRows, intCols, intSR, intSC, SNAKE_HEAD);
    int intSR = myGameWorld.snakeHead.intRow;
    int intSC = myGameWorld.snakeHead.intCol;

    //Destination
    int intDR = intSR;
    int intDC = intSC;

    //Change Destination
    switch(chInput){
        case 'w':
            {
                intDR--;
                break;
            }
        case 's':
            {
                intDR++;
                break;
            }
        case 'a':
            {
                intDC--;
                break;
            }
        case 'd':
            {
                intDC++;
                break;
            }
    }

    //Is Destination Valid?
    if(isValid(myGameWorld.intRows, myGameWorld.intCols, intDR, intDC)){
        //findFeature, snake tail -> I know where it is
//        int intSTR = -1;
//        int intSTC = -1;
//        findFeature(arrGame, intRows, intCols, intSTR, intSTC, SNAKE_TAIL);
        int intSTR = myGameWorld.snakeTail.intRow;
        int intSTC = myGameWorld.snakeTail.intCol;

        //Check if destination is fruit
        if(myGameWorld.arrGame[intDR][intDC] == FRUIT){
            //Count Fruits eaten
            //fruitCount++;
            myGameWorld.fruitsCollected++;
            //Move
            myGameWorld.snakeHead.intRow = intDR;
            myGameWorld.snakeHead.intCol = intDC;
            myGameWorld.arrGame[intDR][intDC] = SNAKE_HEAD;
            //Grow snake (change previous to body) -> KEEP PREVIOUS, DO NOT MOVE
            myGameWorld.arrGame[intSR][intSC] = SNAKE_BODY;
            //Add to list
            //Insert at beginning
            myGameWorld.snakeBody.insert(myGameWorld.snakeBody.begin(), {intSR, intSC}); //Insert Struct into Vector
            //Place new fRUIT
            placeFeature(myGameWorld, FRUIT);
            //myGameWorld.fruit = {}; //Get Position of Placed Fruit -> maybe add to place Feature, make it placeFruit
        }else if(myGameWorld.arrGame[intDR][intDC] == GRASS){
            //Move

            //Head
            Coordinate prevHead = {myGameWorld.snakeHead.intRow, myGameWorld.snakeHead.intCol};
            myGameWorld.snakeHead.intRow = intDR;
            myGameWorld.snakeHead.intCol = intDC;
            myGameWorld.arrGame[intDR][intDC] = SNAKE_HEAD;
            //Move Body
            if(myGameWorld.fruitsCollected > 0){
                moveSnakeBody(myGameWorld, prevHead);
            }else{
//                //findFeature, snake tail
//                int intSTR = -1;
//                int intSTC = -1;
//                findFeature(arrGame, intRows, intCols, intSTR, intSTC, SNAKE_TAIL);
                //Move Tail
                myGameWorld.snakeTail = {intSR, intSC};
                myGameWorld.arrGame[intSR][intSC] = SNAKE_TAIL;
            }
            //Move Tail, leave grass
            myGameWorld.arrGame[intSTR][intSTC] = GRASS;

        }else if(myGameWorld.arrGame[intDR][intDC] == SNAKE_BODY || myGameWorld.arrGame[intDR][intDC] == SNAKE_TAIL){
            //Move into itself
            //Ate yourself, GAME OVER.
            myGameWorld.ateSelf = true;
        }
    }
}

}
