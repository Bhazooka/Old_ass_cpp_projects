#ifndef LIBSNAKE_H_INCLUDED
#define LIBSNAKE_H_INCLUDED

#include <iostream>
#include <vector>

using namespace std;

namespace SnakeSpace{

struct Coordinate{
    int intRow;
    int intCol;
};

enum StatusCodes{
    ERR_CONVERT,
    ERR_COUNT,
    ERR_RANGE
};

//features
enum Features{
    GRASS,
    SNAKE_HEAD,
    SNAKE_TAIL,
    SNAKE_BODY, // Keeps growing
    FRUIT
};

const int MIN_SIZE = 5;
const int MAX_SIZE = 50;

const int FEATURE_CHARS[5] = {249, 178, 177, 177, 232}; // Extended Ascii Chars, can't mix

typedef int* OneDArray;
typedef OneDArray* TwoDArray;

struct GameWorld{
    Coordinate snakeHead;
    Coordinate snakeTail;
    vector<Coordinate> snakeBody;
    int intRows;
    int intCols;
    //Coordinate fruit; Do not need to keep track of fruit position
    TwoDArray arrGame;
    int fruitsCollected;
    bool ateSelf = false;
};



//Allocate Memory and Initialize Values
GameWorld createGame(int intRows, int intCols);

//Print Game
void printGame(const GameWorld& myGameWorld);

//Deallocate Memory
void destroyGame(GameWorld& myGameWorld);

int convStrToInt(string strNum);

void pauseGame();

//Move Snake
void moveSnake(GameWorld& myGameWorld, char chInput);

}

#endif // LIBSNAKE_H_INCLUDED
