#include "libSnake.h"

#include <ctime>
#include <cctype>

using namespace std;
using namespace SnakeSpace;

int main(int argc, char** argv)
{
    srand(time(0));

    if(argc != 3){
       cerr << "Wrong number of arguments" << endl;
       cout << "Enter " << argv[0] << " <numRows> <numCols> " << endl;
       exit(ERR_COUNT);
    }

    int intRows = convStrToInt(argv[1]);
    int intCols = convStrToInt(argv[2]);

    if(intRows < MIN_SIZE || intRows > MAX_SIZE || intCols < MIN_SIZE || intCols > MAX_SIZE){
        cerr << "Wrong dimensions entered, must be between 5 and 50" << endl;
        exit(ERR_RANGE);
    }

    //Game World
    GameWorld arrSnakeGame = createGame(intRows, intCols);

    //Menu System

    bool blnContinue = true;
    char chInput = '\0';
    //int fruitCount = 0;
    //bool blnAteSelf = false;

    //vector<Coordinate> snake_body;

    do{
        system("cls");
        printGame(arrSnakeGame);
        cout << "Fruits Eaten: " << arrSnakeGame.fruitsCollected << endl;
        cin >> chInput;
        chInput = tolower(chInput);
        switch(chInput){
        case 'w':
        case 's':
        case 'a':
        case 'd':
            {
                //Change direction of snake

                //Move Snake
                moveSnake(arrSnakeGame, chInput);
                break;
            }
        case 'q':
            {
                //Quit Game
                blnContinue = false;
                break;
            }
        default:
            {
                cerr << "Wrong character entered" << endl;
            }
        }

        pauseGame();

        //Game End
        if(arrSnakeGame.ateSelf){
            blnContinue = false;
        }
    }while(blnContinue);

    //Print Game
    system("cls");
    //printGame(arrSnakeGame, intRows, intCols);
    //Results
    cout << "***********************************************" << endl;
    if(arrSnakeGame.ateSelf){
        cout << "SORRY, the snake ate itself. You loose" << endl;
    }else{
        cout << "You quit the game" << endl;
    }
    cout << "***********************************************" << endl;

    //Deallocate Memory
    destroyGame(arrSnakeGame);
    return 0;
}
