#include "libScale.h"
#include <cctype>
using namespace ScaleSpace;

int main(int argc, char** argv)
{
    //seed the random number generator.
    srand(time(nullptr));

    //local variables
    strucGame tGame;
    char chInput='\0';

    //ensure the correct number of command line args were provided.
    if(argc != 5)
    {
        cerr<<"Incorrect number of command line arguments. Expected: "<<argv[0]
            <<" <Total Rows> <Total Cols> <Total Number of Weights> <Total Number of Scales>"<<endl;

        exit(ERR_ARG_COUNT);
    }

    //convert the command line arguments into integers.
    int intRows = ConvertToInt(argv[1]);
    int intCols = ConvertToInt(argv[2]);
    int intTotalWeight = ConvertToInt(argv[3]);
    int intNumScales = ConvertToInt(argv[4]);

    //check if the provided values are within range.
    CheckRange(intRows,MIN_DIMENSION,MAX_DIMENSION, "Total Rows");
    CheckRange(intCols,MIN_DIMENSION,MAX_DIMENSION, "Total Cols");
    //The number of weights CANNOT be less than the number of scales.
    //otherwise we will not have enough weights to place on each scale. e.g. 2 scales, 1 weight.
    //We need to get the available cells for the weights
    // get the dimensions of the world. Subtract the number of scales and 1 (for the player).
    int intAvailableWeightCells = (intRows * intCols) -intNumScales -1;
    CheckRange(intTotalWeight, intNumScales, intAvailableWeightCells, "Total Weights");
    //We need to get the available cells for the scales.
    // get the dimensions of the world. Subtract the number of weights and 1 (for the player).
    int intAvailableScaleCells = (intRows * intCols) -intTotalWeight -1;
    CheckRange(intNumScales, MIN_SCALES,intAvailableScaleCells,"Total Scales");

    //create the game
    tGame = InitialiseGame(intRows,intCols, intTotalWeight, intNumScales);

    do
    {
        //Show the game state
        DisplayWorld(tGame);

        //get the user's input
        cin>>chInput;

        //process the user's input. Convert to lower case so we only have to check for lower case letters
        switch(tolower(chInput))
        {
            case 'w':
            {
                MovePlayer(tGame, UP);
                break;
            }
            case 's':
            {
                MovePlayer(tGame, DOWN);
                break;
            }
            case 'a':
            {
                MovePlayer(tGame, LEFT);
                break;
            }
            case 'd':
            {
                MovePlayer(tGame, RIGHT);
                break;
            }
            case 'q':
            {
                MovePlayer(tGame, UP_LEFT);
                break;
            }
            case 'e':
            {
                MovePlayer(tGame, UP_RIGHT);
                break;
            }
            case 'z':
            {
                 MovePlayer(tGame, DOWN_LEFT);
                break;
            }
            case 'x':
            {
                MovePlayer(tGame, DOWN_RIGHT);
                break;
            }
            case 't':
            {
                DropWeight(tGame);
                break;
            }
            case 'l':
            {
                tGame.tPlayerStatus = QUIT;
                break;
            }
        }
    //stop the loop if the player's status has changed from running
    }while(tGame.tPlayerStatus == RUNNING);

    //process the game result.
    PrintResult(tGame.tPlayerStatus);

    //return the allocated resources
    FreeMemory(tGame.arrWorld, tGame.intRows);

    return SUCCESS;
}
