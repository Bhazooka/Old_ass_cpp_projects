#ifndef LIBSCALE_H_INCLUDED
#define LIBSCALE_H_INCLUDED

#include <iostream>
#include <ctime>
#include <sstream>
#include <cstdlib>
#include <cassert>

using namespace std;

namespace ScaleSpace
{

    //enums
    enum eArgRange
    {
        MIN_DIMENSION = 5,
        MAX_DIMENSION = 30,
        MIN_SCALES =1
    };
    enum eGameStatus
    {
        SUCCESS=0,
        ERR_ARG_CONVERSION=-1,
        ERR_ARG_COUNT=-2,
        ERR_ARG_RANGE=-3,
    };

    enum ePlayerStatus
    {
        WIN,
        LOSE,
        RUNNING,
        QUIT
    };

    enum eDirection
    {
        UP,
        DOWN,
        LEFT,
        RIGHT,
        UP_LEFT,
        UP_RIGHT,
        DOWN_LEFT,
        DOWN_RIGHT
    };

    enum eSymbols
    {
        EMPTY=0,
        PLAYER=-1,
        WEIGHT=-2,
    };

    const char SYMBOLS[] ={'.', 'P', 'X'};
    const int RANDOM_DROP_RADIUS =1;

    typedef int* t1DArray;
    typedef int** t2DArray;

    struct strucGame
    {
        int intRows;
        int intCols;
        int intPRow;
        int intPCol;
        int intRemainingScales;
        int intPickedUpWeights;
        int intTempScaleValue;

        ePlayerStatus tPlayerStatus;
        t2DArray arrWorld;

    };



    //game functions
    //initialise the scale game according to the provided command parameters
    strucGame InitialiseGame(int intRows, int intCols, int intTotalWeight, int intNumScales);
    //display the current state of the world with informative information.
    void DisplayWorld(strucGame tGame);
    //get the destination location, given the movement direction.
    void GetDestinationLocation(int intPRow, int intPCol, int& intDRow, int& intDCol, eDirection tDirection);
    //move the player in the provided direction
    void MovePlayer(strucGame& tGame, eDirection tDirection);
    //place a feature randomly, given the min & max rows and cols
    void PlaceFeature(t2DArray arrWorld, int intMinRow, int intMaxRow, int intMinCol, int intMaxCol, int intFeatureToPlace);
    //place a feature randomly within the bounds of the 2D array
    void PlaceFeature(strucGame& tGame, int intFeatureToPlace);
    //move the player in the provided direction
    void DropWeight(strucGame& tGame);


    //helper functions
    //convert a string input into an integer
    int ConvertToInt(string strInput);
    //generate a random integer within a given range
    int RandInt(int intLowerBound, int intUpperBound);
    //Check if the provided value is within the given range.
    void CheckRange(int intValue, int intMin, int intMax, string strValueName);
    //check if the provided value is within the provided bounds.
    bool IsWithinBounds(int intRow, int intCol, int intRows, int intCols);
    //allocate the memory for a 2D array
    t2DArray AllocateMemory(int intRows, int intCols,int intInitialValue);
    //Free the memory of a 2D Array.
    void FreeMemory(t2DArray& arrWorld, int intRows);
    //Free the memory of a 2D Array.
    void Pause();
    //Display the Result of the game
    void PrintResult(ePlayerStatus tPlayerStatus);
}


#endif // LIBSCALE_H_INCLUDED
