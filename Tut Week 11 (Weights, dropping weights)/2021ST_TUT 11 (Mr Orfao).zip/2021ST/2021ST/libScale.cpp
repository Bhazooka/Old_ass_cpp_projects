#include "libScale.h"

namespace ScaleSpace
{

    //initialise the scale game according to the provided command parameters
    strucGame InitialiseGame(int intRows, int intCols, int intTotalWeight, int intNumScales)
    {
        //create the game structure
        strucGame tGame;
        //assign the relevant values.
        tGame.intRows=intRows;
        tGame.intCols=intCols;
        tGame.intRemainingScales=intNumScales;
        tGame.intPickedUpWeights=0;
        tGame.intTempScaleValue=-1;
        tGame.tPlayerStatus = RUNNING;
        tGame.arrWorld = AllocateMemory(intRows, intCols, EMPTY);

        //Note the player should start in the middle of the map
        tGame.intPRow= intRows/2;
        tGame.intPCol = intCols/2;

        //place the player in the world
        tGame.arrWorld[tGame.intPRow][tGame.intPCol] = PLAYER;

        //place the weights randomly within the world
        for(int w=0; w<intTotalWeight; w++)
        {
            PlaceFeature(tGame,WEIGHT);
        }

        //place the scales randomly within the world
        //For a scale to exist, it should at least have 1 weight.
        //therefore, we can give each scale 1 weight and see how much is remaining to distribute.
        int intAmountToDistribute = intTotalWeight-intNumScales;
        //track the random amount that will be added to each scale.
        int intRandAdditionAmount;
        //loop through all the scales except for 1. Leave this aside for now.
        for(int s=0; s<intNumScales-1; s++)
        {
            //determine the random amount to add onto the current scale between 0 and the amount remaining to distribute.
            intRandAdditionAmount= RandInt(0,intAmountToDistribute);
            //randomly place the scale into the world with its initial value of 1 plus any random extra amount.
            PlaceFeature(tGame, 1+ intRandAdditionAmount);
            //subtract the random addition amount from the amount that is available to distribute.
            //this will ensure our random addition amount does not exceed what we are allowed to distribute.
            intAmountToDistribute -= intRandAdditionAmount;
        }
        //finally, place the last scale in the world with its initial
        //value of 1 plus the remaining amount that was NOT randomly distributed.
        //This ensures that the sum of the scale values = the total weights available.
        PlaceFeature(tGame, 1+ intAmountToDistribute);

        return tGame;
    }

    //display the current state of the world with informative information.
    void DisplayWorld(strucGame tGame)
    {
        //clear the screen
        system("cls");

        for(int r=0; r<tGame.intRows; r++)
        {
            for(int c=0; c<tGame.intCols; c++)
            {
                //if the current cell is empty. i.e = to 0
                if(tGame.arrWorld[r][c] == EMPTY)
                {
                    //index into the symbols array to get the empty character. i.e. at index 0
                    cout<<SYMBOLS[tGame.arrWorld[r][c]];
                }
                //if the current cell is the player. i.e. = -1
                else if(tGame.arrWorld[r][c] == PLAYER)
                {
                    //multiply by -1 to get a positive index value. i.e. 1
                    int intIndex = tGame.arrWorld[r][c] *-1;
                    //index into the symbols array to get the player character. i.e. at index 1
                    cout<<SYMBOLS[intIndex];
                }
                //if the current cell is a weight. i.e. = -2
                else if(tGame.arrWorld[r][c] == WEIGHT)
                {
                    //multiply by -1 to get a positive index value. i.e. 2
                    int intIndex = tGame.arrWorld[r][c] *-1;
                    //index into the symbols array to get the weight character. i.e. at index 2
                    cout<<SYMBOLS[intIndex];
                }
                else
                {
                    //otherwise the value is a positive number. This means it is the value on the scale.
                    //output the scale value
                    cout<<tGame.arrWorld[r][c];
                }
                //separate the column values by 1 space.
                cout<<" ";
            }
            //go to a new line
            cout<<endl;
        }

        //output informative information
        cout<<endl<<"Weights Collected: "<<tGame.intPickedUpWeights<<endl
            <<"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"<<endl
            <<"Press:"<<endl
            <<"W: UP"<<endl
            <<"S: DOWN"<<endl
            <<"A: LEFT"<<endl
            <<"D: RIGHT"<<endl
            <<"Q: UP LEFT"<<endl
            <<"E: UP RIGHT"<<endl
            <<"Z: DOWN LEFT"<<endl
            <<"X: DOWN RIGHT"<<endl
            <<"T: THROW WEIGHT"<<endl
            <<"L: LEAVE"<<endl;
    }

    //get the destination location, given the movement direction.
    void GetDestinationLocation(int intPRow, int intPCol, int& intDRow, int& intDCol, eDirection tDirection)
    {
        //Note intDRow and intDCol are passed by reference. This is to update their current value.
        //A.K.A returning more than 1 value from a function.
        intDRow = intPRow;
        intDCol = intPCol;
        switch(tDirection)
        {
            case UP:
            {
                intDRow--;
                break;
            }
            case DOWN:
            {
                intDRow++;
                break;
            }
            case LEFT:
            {
                intDCol--;
                break;
            }
            case RIGHT:
            {
                intDCol++;
                break;
            }
            case UP_LEFT:
            {
                intDRow--;
                intDCol--;
                break;
            }
            case UP_RIGHT:
            {
                intDRow--;
                intDCol++;
                break;
            }
            case DOWN_LEFT:
            {
                intDRow++;
                intDCol--;
                break;
            }
            case DOWN_RIGHT:
            {
                intDRow++;
                intDCol++;
                break;
            }

        }
    }

    //move the player in the provided direction
    void MovePlayer(strucGame& tGame, eDirection tDirection)
    {
        int intDRow =-1;
        int intDCol =-1;
        //track if the player has moved onto a scale.
        int intTempScaleValue =-1;
        //get the destination column, given the movement direction
        GetDestinationLocation(tGame.intPRow, tGame.intPCol,intDRow,intDCol,tDirection);

        //ensure that the destination row and column were updated
        assert(intDRow>=0);
        assert(intDCol>=0);

        //Test if the destination row and column are within the world bounds
        if(IsWithinBounds(intDRow, intDCol, tGame.intRows-1, tGame.intCols-1))
        {
            //if we are moving into an empty location
            if(tGame.arrWorld[intDRow][intDCol] == EMPTY)
            {
                //just move the player. This gets done below.
            }
            //if we are moving into place where there is a weight
            else if(tGame.arrWorld[intDRow][intDCol] == WEIGHT)
            {
                //pick up the weight
                tGame.intPickedUpWeights++;
            }
            else //we are moving into a scale
            {
                //if we have no weights picked up
                if(tGame.intPickedUpWeights ==0)
                {
                    //track the scale value so we can put it back when we move away.
                    intTempScaleValue = tGame.arrWorld[intDRow][intDCol];
                }
                else //we have weights that can be dropped
                {
                    //get the amount of weight remaining on the scale
                    int intScaleRemaining = tGame.arrWorld[intDRow][intDCol] - tGame.intPickedUpWeights;
                    //if there is nothing remaining
                    if(intScaleRemaining == 0)
                    {
                        //remove the scale
                        tGame.arrWorld[intDRow][intDCol] = EMPTY; //int Scale remaining should be 0 which is our empty value
                        //Decrease the scales remaining.
                        tGame.intRemainingScales--;
                        //reset the picked up weights because we drop all of them at once.
                        tGame.intPickedUpWeights =0;
                    }
                    else //we either had too little or too much weight so we lose.
                    {
                        tGame.tPlayerStatus = LOSE;
                        return;
                    }
                }
            }

            //if there are no scales remaining
            if(tGame.intRemainingScales ==0)
            {
                //we win. Stop the game
                tGame.tPlayerStatus = WIN;
                return;
            }
            //if we have previously kept track of a scale value
            if(tGame.intTempScaleValue != -1)
            {
                //place the value back into the world when we move away
                tGame.arrWorld[tGame.intPRow][tGame.intPCol] = tGame.intTempScaleValue;
                //reset the scale value so we can track another scale's value if we need.
                tGame.intTempScaleValue =-1;
            }
            else
            {
                //we do not have anything that we need to place back into the world. We can make our current location empty
                tGame.arrWorld[tGame.intPRow][tGame.intPCol] = EMPTY;
            }
            //if we have gone over a scale when we have no weights.
            if(intTempScaleValue != -1)
            {
                //we need to track this value so we can place it back when we move away.
                tGame.intTempScaleValue = intTempScaleValue;

            }
            //Update the players row and col
            tGame.intPRow = intDRow;
            tGame.intPCol = intDCol;

            //Move the player in the world.
            tGame.arrWorld[tGame.intPRow ][tGame.intPCol] = PLAYER;
        }
    }
    //place a feature randomly within the bounds of the 2D array
    void PlaceFeature(strucGame& tGame, int intFeatureToPlace)
    {
        //place the feature using the bounds of the world
        PlaceFeature(tGame.arrWorld,0, tGame.intRows-1, 0, tGame.intCols-1,intFeatureToPlace);
    }

    //place a feature randomly, given the min & max rows and cols
    void PlaceFeature(t2DArray arrWorld, int intMinRow, int intMaxRow, int intMinCol, int intMaxCol, int intFeatureToPlace)
    {
        //create a random row
        int intRandRow = RandInt(intMinRow, intMaxRow);
        int intRandCol = RandInt(intMinCol, intMaxCol);

        //continue to generate a random row until the location in the array is empty
        while(arrWorld[intRandRow][intRandCol] != EMPTY)
        {
             intRandRow = RandInt(intMinRow, intMaxRow);
             intRandCol = RandInt(intMinCol, intMaxCol);
        }
        //Place the feature in the array
        arrWorld[intRandRow][intRandCol] = intFeatureToPlace;
    }

    //Randomly drop a weight
    void DropWeight(strucGame& tGame)
    {
        //make sure you have picked up a weight
        if(tGame.intPickedUpWeights==0)return;

        bool blnIsOpen = false;

        //test if there is an open space around the player where the weight can be dropped.
        //Note the condition in the For Loops. We can STOP searching if we know there is at least 1 open space.
        for(int r=tGame.intPRow-1; (r<=tGame.intPRow+1)&&(blnIsOpen==false); r++)
        {
            for(int c=tGame.intPCol-1; (c<=tGame.intPCol+1)&&(blnIsOpen==false); c++)
            {
                if(tGame.arrWorld[r][c] == EMPTY)
                {
                    //we can stop searching, we know there is at least 1 open space
                    blnIsOpen = true;
                }
            }
        }

        //if there is an open space
        if(blnIsOpen)
        {
            //randomly place the the weight within the drop radius of the player.
            int intMinRow = tGame.intPRow-RANDOM_DROP_RADIUS;
            int intMaxRow = tGame.intPRow+RANDOM_DROP_RADIUS;
            int intMinCol = tGame.intPCol-RANDOM_DROP_RADIUS;
            int intMaxCol = tGame.intPCol+RANDOM_DROP_RADIUS;

            PlaceFeature(tGame.arrWorld, intMinRow,intMaxRow,intMinCol, intMaxCol, WEIGHT);
            //decrease the amount of weights the player has collected.
            tGame.intPickedUpWeights --;
        }
        else
        {
            //if there is no open space, you lose.
            tGame.tPlayerStatus = LOSE;
        }
    }

    //convert a string input into an integer
    int ConvertToInt(string strInput)
    {
        //declare the variable to place the converted integer into
        int intConverted;
        //initialise the stringstream with the current input that we want to convert to an integer
        stringstream ss(strInput);
        //perform the conversion
        ss>>intConverted;

        //test if the conversion was successfull
        if(ss.fail())
        {
            cerr<<"Could not convert the following into an integer: "<<strInput<<endl;
            exit(ERR_ARG_CONVERSION);
        }
        //all good, we can return the converted integer.
        return intConverted;
    }

    //generate a random integer within a given range
    int RandInt(int intLowerBound, int intUpperBound)
    {
        int intRange = intUpperBound-intLowerBound+1;
        return rand() % intRange + intLowerBound;
    }

    //Check if the provided value is within the given range.
    void CheckRange(int intValue, int intMin, int intMax, string strValueName)
    {
        if(intValue<intMin && intValue>intMax)
        {
            cerr <<"Error: "<<strValueName<<" with value "<<intValue<<" Is not within ["<<intMin<<", "<<intMax<<"]."<<endl;
            exit(ERR_ARG_RANGE);
        }
    }

    //check if the provided value is within the provided bounds.
    bool IsWithinBounds(int intRow, int intCol, int intRows, int intCols)
    {
        return intRow>=0 && intRow <=intRows && intCol>=0 && intCol<=intCols;
    }

    //allocate the memory for a 2D array
    t2DArray AllocateMemory(int intRows, int intCols, int intInitialValue)
    {
        //create the 2D array
        t2DArray tempArr = new t1DArray[intRows];

        //loop through the rows.
        for(int r=0; r<intRows; r++)
        {
            //allocate an array the size of the columns for each row.
            tempArr[r] = new int[intCols];
            for(int c=0; c<intCols; c++)
            {
                //initialise the cells in the array to the provided initial value.
                tempArr[r][c] = intInitialValue;
            }
        }

        return tempArr;
    }

    //Free the memory of a 2D Array.
    void FreeMemory(t2DArray& arrWorld, int intRows)
    {
        //check to see if the array has been deleted already. Stop executing the code if it has as we have a logic error.
        assert(arrWorld != nullptr);

        //loop through the rows.
        for(int r=0; r<intRows; r++)
        {
            //delete the block of memory allocated for the cols at the current row.
            delete[] arrWorld[r];
        }

        //delete the block of memory allocated for the rows.
        delete[] arrWorld;

        //make the address of the array point to null. This is why you need to pass by Reference.
        arrWorld = nullptr;
    }

    //pause the game
    void Pause()
    {
        string strJunk;
        getline(cin, strJunk);
        cout<<"Press any key to continue"<<endl;
        getline(cin, strJunk);
    }

    //Display the Result of the game
    void PrintResult(ePlayerStatus tPlayerStatus)
    {
        system("cls");
        cout<<"*****************************************************"<<endl;

        switch(tPlayerStatus)
        {
            case WIN:
            {
                cout<<"*                       YOU WIN                     *"<<endl;
                break;
            }
            case LOSE:
            {
                cout<<"*                      YOU LOSE                     *"<<endl;
                break;
            }
            case QUIT:
            {
                cout<<"*                      YOU QUIT                     *"<<endl;
                break;
            }
            default:
            {
                cout<<"*                      UNHANDLED                    *"<<endl;
                break;
            }
        }
        cout<<"*****************************************************"<<endl;
    }
}
