#ifndef LIBWEIGHTS_H_INCLUDED
#define LIBWEIGHTS_H_INCLUDED

#include <iostream>


using namespace std;

namespace ScaleSpace{

enum StatusCodes{
    SUCCESS, ERR_ARGCOUNT, ERR_CONV, ERR_RANGE
};

enum gameState
    {
        RUNNING,
        WON,
        LOST,
        QUIT
    };


typedef int* OneDArray;
typedef OneDArray* TwoDArray;

const int PLAYER = -1;
const int EMPTY = 0;
const int WEIGHT = 100;

const char CH_EMPTY = '.';
const char CH_WEIGHT = 'X';
const char CH_PLAYER = 'P';

struct Coordinate{
    int intRow;
    int intCol;
};

struct GameWorld{
    TwoDArray arrGame;
    int intRows;
    int intCols;
    Coordinate playerPosition;
    gameState state;
    int weightCarry;
    int intScales;
};

int convStrToInt(string strNum);
int generateRandomNum(int intLower, int intUpper);

GameWorld createGame(int intRows, int intCols, int intWeight, int intScales);
void printGame(GameWorld myGame);
void movePlayer(GameWorld& myGame, char chInput);
void deallocMemory(TwoDArray& arrGame, int intRows);
void dropWeight(GameWorld& myGame);
}

#endif // LIBWEIGHTS_H_INCLUDED
