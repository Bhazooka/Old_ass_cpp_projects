#include "libWeights.h"

#include <sstream>
#include <iomanip>
#include <cassert>

namespace ScaleSpace{

int convStrToInt(string strNum){
    int intNum = 0;
    stringstream ss {strNum};
    ss >> intNum;
    if(ss.fail()){
        cerr << "Failed to convert to Int" << endl;
        exit(ERR_CONV);
    }
    return intNum;
}

int generateRandomNum(int intLower, int intUpper) {
    int intRange = intUpper - intLower + 1;
    return rand() % intRange + intLower;
}

TwoDArray initArray(int intRows, int intCols){
    TwoDArray arrGame;
    arrGame = new OneDArray[intRows];
    for(int r = 0; r < intRows; r++){
        arrGame[r] = new int[intCols];
        for(int c = 0; c < intCols; c++){
            arrGame[r][c] = EMPTY;
        }
    }
    return arrGame;
}

void placeFeatures(GameWorld& myGame, int intCount, int intFeature){
    int intRow = 0;
    int intCol = 0;
    for(int i = 0; i < intCount; i++){
        intRow = generateRandomNum(0, myGame.intRows - 1);
        intCol = generateRandomNum(0, myGame.intCols - 1);
        while(myGame.arrGame[intRow][intCol] != EMPTY){
            intRow = generateRandomNum(0, myGame.intRows - 1);
            intCol = generateRandomNum(0, myGame.intCols - 1);
        }
        myGame.arrGame[intRow][intCol] = intFeature;
    }
}

GameWorld createGame(int intRows, int intCols, int intWeight, int intScales){
    GameWorld myGame;
    myGame.intRows = intRows;
    myGame.intCols = intCols;
    myGame.state = RUNNING;
    myGame.intScales = intScales;
    myGame.weightCarry = 0;

    //Place Player
    int intPR = intRows/2;
    int intPC = intCols/2;
    //Coordinate playerPosition = {intPR, intPC};
    Coordinate playerPosition;
    playerPosition.intRow = intPR;
    playerPosition.intCol = intPC;
    myGame.playerPosition = playerPosition;

    //Two Dimensional Array
    myGame.arrGame = initArray(intRows, intCols);

    //Place Features

    //place Player
    myGame.arrGame[intPR][intPC] = PLAYER;

    //Weight
    placeFeatures(myGame, intWeight, WEIGHT);
    //Scales
    for(int n = intScales - 1; n>= 1; n--){
        int intRange = intWeight - n;
        int intScaleValue = generateRandomNum(1, intRange);
        placeFeatures(myGame, 1, intScaleValue);
        intWeight -= intScaleValue;
    }
    //Place last scale
    placeFeatures(myGame, 1, intWeight);

    return myGame;
}

void printGame(GameWorld myGame){
    for(int r = 0; r < myGame.intRows; r++){
        for(int c = 0; c < myGame.intCols; c++){
            cout << setw(3);
            int intFeature = myGame.arrGame[r][c];
            if(intFeature == PLAYER){
                cout << CH_PLAYER;
            }else if(intFeature == EMPTY){
                cout << CH_EMPTY;
            }else if(intFeature == WEIGHT){
                cout << CH_WEIGHT;
            }else{
                cout << intFeature;
            }
        }
        cout << endl;
    }
}

bool isValid(int intRows, int intCols, int intDR, int intDC){
    return (intDR >= 0 && intDR < intRows && intDC >= 0 && intDC < intCols);
}

void movePlayer(GameWorld& myGame, char chInput){
    int intDR = myGame.playerPosition.intRow;
    int intDC = myGame.playerPosition.intCol;

    switch(chInput){
        case 'w':
        {
            intDR--;
            break;
        }
        case 'x':
        {
            intDR++;
            break;
        }
        case 'a':
        {
            intDC--;
            break;
        }
        case 'd':
        {
            intDC++;
            break;
        }
        case 'q':
        {
            intDR--;
            intDC--;
            break;
        }
        case 'e':
        {
            intDR--;
            intDC++;
            break;
        }
        case 'z':
        {
            intDR++;
            intDC--;
            break;
        }
        case 'c':
        {
            intDR++;
            intDC++;
            break;
        }
    }

    //Valid Destination
    if(isValid(myGame.intRows, myGame.intCols, intDR, intDC)){
        //Check is destination weight?
        if(myGame.arrGame[intDR][intDC] == WEIGHT){
            //Move Player
            myGame.arrGame[intDR][intDC] = PLAYER;
            myGame.arrGame[myGame.playerPosition.intRow][myGame.playerPosition.intCol] = EMPTY;
            myGame.playerPosition = {intDR, intDC};
            myGame.weightCarry++;
        }else if(myGame.arrGame[intDR][intDC] > 0 && myGame.arrGame[intDR][intDC] < 100){
            if(myGame.weightCarry > 0){
                int intDifference = myGame.arrGame[intDR][intDC] - myGame.weightCarry;
                if(intDifference == 0){
                    myGame.arrGame[intDR][intDC] = PLAYER;
                    myGame.arrGame[myGame.playerPosition.intRow][myGame.playerPosition.intCol] = EMPTY;
                    myGame.playerPosition = {intDR, intDC};
                    myGame.intScales--;
                    myGame.weightCarry = 0;
                }else{
                    myGame.state = LOST;
                }
            }
        }else{
            myGame.arrGame[intDR][intDC] = PLAYER;
            myGame.arrGame[myGame.playerPosition.intRow][myGame.playerPosition.intCol] = EMPTY;
            myGame.playerPosition = {intDR, intDC};
        }
    }
}

void deallocMemory(TwoDArray& arrGame, int intRows){
    assert(arrGame != nullptr);
    for(int r = 0; r < intRows; r++){
        delete [] arrGame[r];
    }
    delete [] arrGame;
    arrGame = nullptr;
}

bool freeNeighbours(GameWorld& myGame){
    //Check if entire neighbourhood occupied
    int noFreeNeighbours = 0;
    for(int r = myGame.playerPosition.intRow - 1; r <= myGame.playerPosition.intRow + 1; r++){
        for(int c = myGame.playerPosition.intCol - 1; c <= myGame.playerPosition.intCol + 1; c++){
            //Valid
            if(isValid(myGame.intRows, myGame.intCols, r, c)){
                //Not self
                if(myGame.arrGame[r][c] == EMPTY ){
                    noFreeNeighbours++;
                }
            }

        }
    }

    if(noFreeNeighbours < 1){
        //Fully Occupied, cannot drop
        myGame.state = LOST;
        return false;
    }
    return true;
}
void dropWeight(GameWorld& myGame){
    //First check if player has weights
    if(myGame.weightCarry < 1){
        return;
    }

    if(freeNeighbours(myGame)){
        //Place/drop item randomly in empty space
        int intDRow = generateRandomNum(myGame.playerPosition.intRow - 1, myGame.playerPosition.intRow + 1);
        int intDCol = generateRandomNum(myGame.playerPosition.intCol - 1, myGame.playerPosition.intCol + 1);
        while(!isValid(myGame.intRows, myGame.intCols, intDRow, intDCol) || myGame.arrGame[intDRow][intDCol] != EMPTY){
            intDRow = generateRandomNum(myGame.playerPosition.intRow - 1, myGame.playerPosition.intRow + 1);
            intDCol = generateRandomNum(myGame.playerPosition.intCol - 1, myGame.playerPosition.intCol + 1);
        }

        myGame.arrGame[intDRow][intDCol] = WEIGHT;
        //Reduce weight count
        myGame.weightCarry--;

    }else{
        myGame.state = LOST;
    }
}

}
