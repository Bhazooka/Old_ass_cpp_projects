#include "libWeights.h"
#include <ctime>
#include <cstdlib>

using namespace ScaleSpace;

int main(int argc, char** argv)
{
    srand(time(nullptr));

    if(argc != 5){
        cerr << "Wrong number of arguments" << endl;
        cout << argv[0] << " <intRows> <intCols> <totalWeight> <numScales>" << endl;
        exit(ERR_ARGCOUNT);
    }

    int intRows = convStrToInt(argv[1]);
    int intCols = convStrToInt(argv[2]);
    int intTotalWeight = convStrToInt(argv[3]);
    int intNumScales = convStrToInt(argv[4]);

    bool blnContinue = true;
    char chInput = '\0';

    GameWorld theGame = createGame(intRows, intCols, intTotalWeight, intNumScales);

    do{
        //system("cls");
        printGame(theGame);
        cout << endl;
        cout << "a) Left d) Right w) Up x) Down " << endl
            << "Q) Top Left E) Top Right Z) Bottom Left C) Bottom Right" << endl
            << "S) Drop Wight" << endl;
        cout << "P) Quit Game" << endl;
        cout << "Number of weights carried: " << theGame.weightCarry << endl;
        cout << "Number of Scales left: " << theGame.intScales << endl;
        cin >> chInput;
        chInput = tolower(chInput);
        switch(chInput){
        case 'w':
        case 'x':
        case 'a':
        case 'd':
        case 'q':
        case 'e':
        case 'z':
        case 'c':
            {
                movePlayer(theGame, chInput);
                break;
            }
        case 's':
            {
                dropWeight(theGame);
                break;
            }
        case 'p':
            {
                blnContinue = false;
                break;
            }
        default:
            {
                cerr << "Wrong value entered" << endl;
            }
        }

        //Check Game Status
        if(theGame.state == LOST){
            blnContinue = false;
        }

    }while(blnContinue);

    cout << "======================= END ========================" << endl;
    if(theGame.state == LOST){
        cout << "Sorry. You lost the game" << endl;
    }else if(theGame.state == WON){
        cout << "Well done. You won the game" << endl;
    }else{
        cout << "You exited the game" << endl;
    }
    cout << "====================================================" << endl;


    //Free the memory
    deallocMemory(theGame.arrGame, theGame.intRows);

    return SUCCESS;
}
